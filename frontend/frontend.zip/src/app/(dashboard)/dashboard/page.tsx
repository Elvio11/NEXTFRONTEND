'use client'
export const dynamic = 'force-dynamic'

import { DashboardHome } from '@/components/dashboard/DashboardHome'

export default function DashboardPage() {
    return <DashboardHome />
}
